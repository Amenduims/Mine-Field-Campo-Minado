package com.example.jogominado2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.android.material.button.MaterialButtonToggleGroup;

public class teste extends AppCompatActivity {

    private MaterialButtonToggleGroup btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teste);
    }
}